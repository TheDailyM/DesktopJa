package com.example.kalkulatorpomocy

import android.annotation.SuppressLint
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

lateinit var przycisk_plus: Button
lateinit var przycisk_minus: Button
lateinit var przycisk_gwiazdka: Button
lateinit var przycisk_dash: Button
lateinit var przycisk_jeden: Button
lateinit var przycisk_dwa: Button
lateinit var przycisk_trzy: Button
lateinit var przycisk_cztery: Button
lateinit var przycisk_piec: Button
lateinit var przycisk_szesc: Button
lateinit var przycisk_siedem: Button
lateinit var przycisk_osiem: Button
lateinit var przycisk_diewiec: Button
lateinit var przycisk_zero: Button
lateinit var przycisk_rowne: Button
lateinit var przycisk_reset: Button
lateinit var wyswietlacz: TextView
var liczba_pierwsza = 0
var liczba_druga = 0
var dzialanie = ""
var wynik = 0

/*****************************************************
nazwa klasy: MainActivity
pola: przycisk_plus - przycisk z napisem +
przycisk_minus - przycisk z napisem -
przycisk_gwiazdka - przycisk z napisem *
przycisk_dash - przycisk z napisem /
przycisk_jeden - przycisk z napisem 1
przycisk_dwa - przycisk z napisem 2
przycisk_trzy - przycisk z napisem 3
przycisk_cztery - przycisk z napisem 4
przycisk_piec - przycisk z napisem 5
przycisk_szesc - przycisk z napisem 6
przycisk_siedem - przycisk z napisem 7
przycisk_osiem - przycisk z napisem 8
przycisk_diewiec - przycisk z napisem 9
przycisk_zero - przycisk z napisem 0
przycisk_rowne - przycisk z napisem =
przycisk_reset - przycisk z napisem reset
wyswietlacz - wyświetla liczby i znaki
metody: liczby(arg1: int),  nie zwraca wartości - dodaje liczby do wyświetlacza
znaki(arg1: String), zwraca pierwszą liczbę - dodaje znaki do wyświetlacza
obliczanie(arg1: String), zwraca wynik działania - wyświetla wynik na wyświetlaczu
informacje: na podstawie tej kalsy działa cała aplikacja
autor: Tomasz Kaniuk
*****************************************************/

class MainActivity : AppCompatActivity() {
    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        przycisk_plus = findViewById(/* id = */ R.id.button_dodawanie)
        przycisk_minus = findViewById(/* id = */ R.id.button_odejmowanie)
        przycisk_gwiazdka = findViewById(/* id = */ R.id.button_mnozenie)
        przycisk_dash = findViewById(/* id = */ R.id.button_dzielenie)
        przycisk_jeden = findViewById(/* id = */ R.id.button_1)
        przycisk_dwa = findViewById(/* id = */ R.id.button_2)
        przycisk_trzy = findViewById(/* id = */ R.id.button_3)
        przycisk_cztery = findViewById(/* id = */ R.id.button_4)
        przycisk_piec = findViewById(/* id = */ R.id.button_5)
        przycisk_szesc = findViewById(/* id = */ R.id.button_6)
        przycisk_siedem = findViewById(/* id = */ R.id.button_7)
        przycisk_osiem = findViewById(/* id = */ R.id.button_8)
        przycisk_diewiec = findViewById(/* id = */ R.id.button_9)
        przycisk_zero = findViewById(/* id = */ R.id.button_0)
        przycisk_rowne = findViewById(/* id = */ R.id.button_rownanie)
        przycisk_reset = findViewById(/* id = */ R.id.button_r)
        wyswietlacz = findViewById(/* id = */R.id.wyswietlacz)


        /*
        *                                    DODWANIE LICZBY DO WYŚWIETLACZA
        * */

        przycisk_jeden.setOnClickListener {
            liczby(1);
        }
        przycisk_dwa.setOnClickListener {
            liczby(2);
        }
        przycisk_trzy.setOnClickListener {
            liczby(3);
        }
        przycisk_cztery.setOnClickListener {
            liczby(4);
        }
        przycisk_piec.setOnClickListener {
            liczby(5);
        }
        przycisk_szesc.setOnClickListener {
            liczby(6);
        }
        przycisk_siedem.setOnClickListener {
            liczby(7);
        }
        przycisk_osiem.setOnClickListener {
            liczby(8);
        }
        przycisk_diewiec.setOnClickListener {
            liczby(9);
        }
        przycisk_zero.setOnClickListener {
            liczby(0);
        }

        /*
        *                                      DODAWANIE ZNAKÓW DO WYŚWIETLACZA
        * */

        przycisk_plus.setOnClickListener {
            znaki("+")
        }
        przycisk_minus.setOnClickListener {
            znaki("-")
        }
        przycisk_gwiazdka.setOnClickListener {
            znaki("*")
        }
        przycisk_dash.setOnClickListener {
            znaki("/")
        }

        /*
        *                                     DODAWANIE ZNAU = I RESET
        * */
        przycisk_reset.setOnClickListener {
            wyswietlacz.text = ""
        }
        przycisk_rowne.setOnClickListener {
            liczba_druga = wyswietlacz.text
            Obliczanie(dzialanie)
        }
    }

    private fun liczby(arg1: Int){ //dodawanie liczb do wyświetlacza
        var  stary_text = wyswietlacz.text.toString();
        if ((stary_text !== "+") && (stary_text !=="-") && (stary_text!== "*") && (stary_text!=="/")) {
            wyswietlacz.text = stary_text + "$arg1"
        }
        else {
            dzialanie = wyswietlacz.text.toString()
            wyswietlacz.text = "$arg1"
        }
    }
    private fun znaki(arg1: String){ //usuwanie liczb przed dodaniem znaku i dodawanie znaku do wyswietlacza
        liczba_pierwsza = wyswietlacz.text

        wyswietlacz.text = "$arg1"
    }
    private fun Obliczanie(arg1: String) { //obliczanie po otrzymaniu kliknięciu znaku =
        if(dzialanie == "+"){
            wynik = liczba_pierwsza + liczba_druga
            wyswietlacz.text = wynik.toString()
        }
        else if ( dzialanie == "-"){
            wynik = liczba_pierwsza - liczba_druga
            wyswietlacz.text = wynik.toString()
        }
        else if (dzialanie == "*"){
            wynik = liczba_pierwsza * liczba_druga
            wyswietlacz.text = wynik.toString()
        }
        else{
            if (liczba_druga != 0){
                wynik = liczba_pierwsza / liczba_druga
                wyswietlacz.text = wynik.toString()
            }
            else{
                wyswietlacz.text = "BŁĄD"
            }
        }
    }
}