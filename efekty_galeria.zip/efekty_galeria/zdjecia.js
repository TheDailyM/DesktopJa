var zmienna;
$(function(){
    $('.zdjecie').click(function(){
        $('#przycisk_p').removeAttr("Hidden");
        $('#przycisk_n').removeAttr("Hidden");
    });
    $("#zdjecie1").click(function(){
        $("#miejscenaobraz").empty();
        $("#miejscenaobraz").append("<img src='collector.png' alt='The Collector' width='500px' height='500px' id='1'>");
        zmienna = 1;
    });
    $("#zdjecie2").click(function(){
        $("#miejscenaobraz").empty();
        $("#miejscenaobraz").append("<img src='boots.png' alt='Boots of Swiftness' width='500px' height='500px' id='2'>");
        zmienna = 2;
    });
    $("#zdjecie3").click(function(){
        $("#miejscenaobraz").empty();
        $("#miejscenaobraz").append("<img src='dominiks.png' alt='Lords Dominik s Regards' width='500px' height='500px' id='3'>");
        zmienna = 3;
    });
    $("#zdjecie4").click(function(){
        $("#miejscenaobraz").empty();
        $("#miejscenaobraz").append("<img src='ie.png' alt='Infinity Edge' width='500px' height='500px' id='4'>");
        zmienna = 4;
    });
    $("#zdjecie5").click(function(){
        $("#miejscenaobraz").empty();
        $("#miejscenaobraz").append("<img src='rapidfire.png' alt='Rapid Firecannon' width='500px' height='500px' id='5'>");
        zmienna = 5;
    });
    $("#zdjecie6").click(function(){
        $("#miejscenaobraz").empty();
        $("#miejscenaobraz").append("<img src='bt.png' alt='Bloodthirster' width='500px' height='500px' id='6'>");
        zmienna = 6;
    });

    $("#przycisk_p").click(function(){
        switch(zmienna){
            case 1:
                $("#miejscenaobraz").empty();
                $("#miejscenaobraz").append("<img src='bt.png' alt='Bloodthirster' width='500px' height='500px' id='6'>");
                zmienna=6;
                break;
            case 2:
                $("#miejscenaobraz").empty();
                $("#miejscenaobraz").append("<img src='collector.png' alt='The Collector' width='500px' height='500px' id='1'>");
                zmienna--;
                break;
            case 3:
                $("#miejscenaobraz").empty();
                $("#miejscenaobraz").append("<img src='boots.png' alt='Boots of Swiftness' width='500px' height='500px' id='2'>");
                zmienna--;
                break;
            case 4:
                $("#miejscenaobraz").empty();
                $("#miejscenaobraz").append("<img src='dominiks.png' alt='Lords Dominik s Regards' width='500px' height='500px' id='3'>");
                zmienna--;
                break;
            case 5:
                $("#miejscenaobraz").empty();
                $("#miejscenaobraz").append("<img src='ie.png' alt='Infinity Edge' width='500px' height='500px' id='4'>");
                zmienna--;
                break;
            case 6:
                $("#miejscenaobraz").empty();
                $("#miejscenaobraz").append("<img src='rapidfire.png' alt='Rapid Firecannon' width='500px' height='500px' id='5'>");
                zmienna--;
                break;
        }
    });
    $("#przycisk_n").click(function(){
        switch(zmienna){
            case 1:
                $("#miejscenaobraz").empty();
                $("#miejscenaobraz").append("<img src='boots.png' alt='Boots of Swiftness' width='500px' height='500px' id='6'>");
                zmienna++;
                break;
            case 2:
                $("#miejscenaobraz").empty();
                $("#miejscenaobraz").append("<img src='dominiks.png' alt='Lords Dominik s Regards' width='500px' height='500px' id='1'>");
                zmienna++;
                break;
            case 3:
                $("#miejscenaobraz").empty();
                $("#miejscenaobraz").append("<img src='ie.png' alt='Infinity Edge' width='500px' height='500px' id='2'>");
                zmienna++;
                break;
            case 4:
                $("#miejscenaobraz").empty();
                $("#miejscenaobraz").append("<img src='rapidfire.png' alt='Rapid Firecannon' width='500px' height='500px' id='3'>");
                zmienna++;
                break;
            case 5:
                $("#miejscenaobraz").empty();
                $("#miejscenaobraz").append("<img src='bt.png' alt='Bloodthirster' width='500px' height='500px' id='4'>");
                zmienna++;
                break;
            case 6:
                $("#miejscenaobraz").empty();
                $("#miejscenaobraz").append("<img src='collector.png' alt='The Collector' width='500px' height='500px' id='5'>");
                zmienna=1;
                break;
        }
    });

});