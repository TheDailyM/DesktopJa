package com.example.qrcodeapi

import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import kotlin.system.exitProcess


class MainActivity : AppCompatActivity() {

    lateinit var buttonZamknij: Button;
    lateinit var miasto: EditText;

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        var buttonZamknij = findViewById<Button>(R.id.button);
        var miasto = findViewById<EditText>(R.id.textMiasto);

        miasto.setOnFocusChangeListener {v, b -> {
            
        }}

        buttonZamknij.setOnClickListener(){
            exitProcess(0);
        }

    }

    fun akcja(){

    }
}