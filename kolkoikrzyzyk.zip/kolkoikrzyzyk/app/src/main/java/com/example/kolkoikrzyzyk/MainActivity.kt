package com.example.kolkoikrzyzyk

import android.os.Bundle
import android.widget.Button
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class MainActivity : AppCompatActivity() {

    val button1:Button = findViewById(R.id.button1);
    val button2:Button = findViewById(R.id.button2);
    val button3:Button = findViewById(R.id.button3);
    val button4:Button = findViewById(R.id.button4);
    val button5:Button = findViewById(R.id.button5);
    val button6:Button = findViewById(R.id.button6);
    val button7:Button = findViewById(R.id.button7);
    val button8:Button = findViewById(R.id.button8);
    val button9:Button = findViewById(R.id.button9);
    var zmienna =1;

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        button1.setOnClickListener{
            if (zmienna == 1){
                button1.setText("X");
                zmienna--;
            }
            else{
                button1.setText("0");
                zmienna++;
            }

        }
        button2.setOnClickListener{
            if (zmienna == 1){
                button2.setText("X");
                zmienna--;
            }
            else{
                button2.setText("0");
                zmienna++;
            }

        }
        button3.setOnClickListener{
            if (zmienna == 1){
                button3.setText("X");
                zmienna--;
            }
            else{
                button3.setText("0");
                zmienna++;
            }

        }
        button4.setOnClickListener{
            if (zmienna == 1){
                button4.setText("X");
                zmienna--;
            }
            else{
                button4.setText("0");
                zmienna++;
            }

        }
        button5.setOnClickListener{
            if (zmienna == 1){
                button5.setText("X");
                zmienna--;
            }
            else{
                button5.setText("0");
                zmienna++;
            }

        }
        button6.setOnClickListener{
            if (zmienna == 1){
                button6.setText("X");
                zmienna--;
            }
            else{
                button6.setText("0");
                zmienna++;
            }

        }
        button7.setOnClickListener{
            if (zmienna == 1){
                button7.setText("X");
                zmienna--;
            }
            else{
                button7.setText("0");
                zmienna++;
            }

        }
        button8.setOnClickListener{
            if (zmienna == 1){
                button8.setText("X");
                zmienna--;
            }
            else{
                button8.setText("0");
                zmienna++;
            }

        }
        button9.setOnClickListener{
            if (zmienna == 1){
                button9.setText("X");
                zmienna--;
            }
            else{
                button9.setText("0");
                zmienna++;
            }

        }

    }
}